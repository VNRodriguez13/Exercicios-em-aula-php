<!DOCTYPE html><html>
<head>  <meta charset="utf-8"> <title>Form</title>
</head>
<body>
<form method="get" action="get.php">
Nome:<input type="text" name="txt_nome" id="txt_nome"><br>
E-mail:<input type="text" name="txt_email" id="txt_email"><br>
<input type="submit">
</form></body></html>