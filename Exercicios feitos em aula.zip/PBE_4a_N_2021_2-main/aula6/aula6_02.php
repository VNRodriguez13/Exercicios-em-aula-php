<?php
$usuario[]="Roberta";
$usuario[]="Carlos";
$usuario[]="Marilda";
echo "<br>".$usuario[0];
echo "<br>".$usuario[1];
echo "<br>".$usuario[2];
?>
