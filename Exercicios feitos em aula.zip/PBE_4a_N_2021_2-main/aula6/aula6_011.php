<?php
$i[]="letras de a - g";//i[] índice ou pos 0
$i[2]="letras de h - q";
$i[]="letras de r - z";
$i[3]="E agora???";

$alunos=array("Astrogildo","Belarmina","Abelardo","Pafuncio");
//                [0]          [1]        [2]        [3]
//echo $alunos[2];
echo "<pre>";print_r($i);echo "</pre>";
?>
