<?php
 $cliente=array("Fulano","Beltrano","Sicrano");
 print_r($cliente);
?>
<hr>
Outra forma para utilizar o print_r( ):
<hr>
<?php
 $cliente=array("Fulano","Beltrano","Sicrano");
 echo "<pre>";print_r($cliente);echo "</pre>";
?>
