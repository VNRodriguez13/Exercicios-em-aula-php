<?php
$uf = array("SP","RJ","MG","ES");
foreach ($uf as $valor){
 echo $valor . "<br>";
}
?>
