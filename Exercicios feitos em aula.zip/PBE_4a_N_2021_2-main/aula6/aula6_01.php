<?php
 $cliente=array("Fulano","Beltrano","Sicrano");
 echo "<br>".$cliente[0];
 echo "<br>".$cliente[1];
 echo "<br>".$cliente[2];
?>
