<?php
 $num=279;
 $teste=(($num%2)==0)?"PAR":"ÍMPAR";
 echo $num." - ".$teste
?>