<?php
$i=0; // inicialização do nosso contador;
do {
  echo $i . "<br> ";
  $i++; // incremento do contador
} while ($i < 5);
?>