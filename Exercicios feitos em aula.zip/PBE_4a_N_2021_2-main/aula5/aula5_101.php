<?php
for ($i=0; $i<6; $i+=1) {
 echo $i . " ";
}
/*
Contador:
$i++ 
$i=$i+1
$i+=1

0 3 

*/
?>