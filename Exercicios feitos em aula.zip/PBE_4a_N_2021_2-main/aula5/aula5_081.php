<?php
$i=0;
while($i<=5){
    echo "$i <br>";
    $i++;
}
/*
1) Qual o valor inicial? 0
2) Qual a condição? $i<=5   < <=  > >=
3) Qual o contador? $i++
4) Qual o valor que torna a condição falsa? 6
5) Qual foi o último valor impresso. 5


Desafio 1)
Saída
7
8
9
10

Desafio 2)
Saída
2
1
0

Desafio 3)
3
5
7
9
*/