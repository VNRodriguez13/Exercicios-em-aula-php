<?php
$num=278;
$res=$num%2;
if($res==0){
  echo $num." - PAR";
}
else{
  echo $num." - ÍMPAR";
}
?>