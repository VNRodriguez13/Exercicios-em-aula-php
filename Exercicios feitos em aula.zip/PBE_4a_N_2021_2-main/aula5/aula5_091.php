<?php
$i=7; // inicialização do nosso contador;
do {
  echo $i . "<br> ";
  $i+=2; // contador
} while ($i < 5);
echo "Valor da variável i = $i;"
/*
Saída:
7
Valor da variável i = 9
*/
?>