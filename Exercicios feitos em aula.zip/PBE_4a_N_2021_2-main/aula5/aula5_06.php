<?php
$a=6;
$b=5;
if ($a == $b) {
  echo 'A variável $a é igual a variável $b';
}
elseif ($a < $b){
  echo 'A variável $a é menor que a variável $b';
}
else{
  echo 'A variável $a é maior que a variável $b';
}
?>