<?php
 $a = 5;
 $b = "5";
 if ($a == $b) {
   echo "a = $a, b = $b<br>";
   echo 'A variável $a é igual a variável $b';
 }
?>