<?php
$num=279;
if(($num%2)==0){
 echo $num." - PAR";
}
else{
 echo $num." - ÍMPAR";
}
?>