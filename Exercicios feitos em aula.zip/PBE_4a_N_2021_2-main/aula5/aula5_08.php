<?php
$i=0; // inicialização do contador;
while ($i <= 5) {
  echo $i . "<br> ";
  $i++;
}
?>