<?php
for ($i=0; $i<6; $i++) {
 echo $i . " ";
}
?>