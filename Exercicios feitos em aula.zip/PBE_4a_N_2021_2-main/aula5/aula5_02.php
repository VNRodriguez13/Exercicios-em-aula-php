<?php
$a = 5;
$b = 6;
echo "a = $a, b = $b<br>";
if ($a == $b) {
 echo 'A variável $a é igual a variável $b';
}
else {
 echo 'A variável $a não é igual a variável $b';
}
?>