<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>PHP</title>
</head>
<body>
  <h1>PHP</h1>
  <?php
  print("Prefiro o calor do que frio<br/>");
  print "Prefiro o calor do que frio<br/>";
  ?>
</body>
</html>