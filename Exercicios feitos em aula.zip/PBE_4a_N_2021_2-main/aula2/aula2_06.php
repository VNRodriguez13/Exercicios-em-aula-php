  <?php
    $nota=7.5;
    var_dump($nota);
  ?>