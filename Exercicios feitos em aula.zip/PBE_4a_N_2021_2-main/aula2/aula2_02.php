<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>PHP</title>
</head>
<body>
  <h1>PHP</h1>
  <?php
  echo("Prefiro o calor do que frio<br/>");
  echo "Prefiro o calor do que frio<br/>";
  ?>
</body>
</html>