<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>PHP</title>
</head>
<body>
  <h1>PHP</h1>
  <?php
   echo "Primeira Linha<br>";
   echo "Segunda Linha<br>";
   ?>
</body>
</html>