 <?php
   $_nome="João Antonio";
   $Nome="Alfredo Maciel";
   $valor=123456;
   $nota=7.5;
 ?>