<?php
$x = 100;
echo "x = ".--$x;
echo "<br>x final = ".$x;
?>