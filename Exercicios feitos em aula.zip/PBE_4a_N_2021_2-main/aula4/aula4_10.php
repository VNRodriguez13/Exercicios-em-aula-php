<?php
$a = 10;
$b = "10";
$c = $a!=$b;
$d = $a<>$b;
var_dump($c);
echo "<br>";
var_dump($d);
?>