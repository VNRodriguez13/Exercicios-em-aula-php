<?php
$a = "Maria ";
echo "$a <br>";
$b = "Leopoldina ";
echo "$b <br>";
echo $a . $b;
$b .= $a;
echo "<br>$b";
?>
