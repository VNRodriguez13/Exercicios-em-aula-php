<?php
$idade=25;//número inteiro
$nota=9.75;//número real, float
$nome="Deoclesio";//string 
echo "$nome, tem $idade anos e tirou nota $nota!";
/*
Desafio

Saída: Deoclesio, tem 25 anos e tirou nota 9.75!
*/
?>