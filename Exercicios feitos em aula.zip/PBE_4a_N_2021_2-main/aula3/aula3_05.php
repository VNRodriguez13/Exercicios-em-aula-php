<?php
<<<<<<< HEAD
$_var=true;
echo $_var."<br>";
var_dump($_var);
=======
$nome="Claudete";
$sobrenome = 'Maria';
echo $nome ." ".$sobrenome."<br>";
echo "$nome $sobrenome<br>";
//após testar, substitua as aspas acima por simples
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>