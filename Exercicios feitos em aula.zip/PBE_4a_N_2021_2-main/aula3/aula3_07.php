<?php
<<<<<<< HEAD
$nota = 9.5;
$nova_nota = (int)$nota;
var_dump($nota);
echo "<br>";
var_dump($nova_nota);
=======
$x = null;
echo "x = ".$x."<br>";
var_dump($x);
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>