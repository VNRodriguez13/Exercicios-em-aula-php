<?php
<<<<<<< HEAD
  $dia = 22;
  $mes = "Agosto";
  $ano = 2021;
  $anocompleto = $dia . " de " . $mes . " de " . $ano;
  echo $anocompleto;
=======
echo "Hello World!"; 
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>