<?php
<<<<<<< HEAD
$y=3;
$z=5;
$x=2*$y+$z;
echo "x = ".$x;
=======
define("PI", 3.14);
define("HOST","localhost");
$valor = 2 * PI;
echo HOST . " - ". $valor;
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>