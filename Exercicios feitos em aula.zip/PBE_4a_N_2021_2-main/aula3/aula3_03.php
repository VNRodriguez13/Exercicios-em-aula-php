<?php
<<<<<<< HEAD
$nota = 9.75;
$preco = 100.50;
echo "<br>nota = ".$nota;
echo "<br>preco = ".$preco;
=======
$x = 1234; //número decimal positivo
$y = -123; //número decimal negativo
echo "<br>x = ".$x;
echo "<br>y = ".$y;
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>