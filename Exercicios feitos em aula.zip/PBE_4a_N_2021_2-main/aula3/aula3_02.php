<?php
<<<<<<< HEAD
$x = 1234; //número decimal
$y = -123; //um número negativo
echo "<br>x = ".$x;
echo "<br>y = ".$y;
=======
  $dia = 22;
  $mes = "Agosto";
  $ano = 2021;
  $anocompleto = $dia . " de " . $mes . " de " . $ano;
  echo $anocompleto;
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>