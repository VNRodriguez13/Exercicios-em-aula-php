<?php
$y=3;
$z=5;
$x=2*$y+$z;
echo "x = ".$x;
?>