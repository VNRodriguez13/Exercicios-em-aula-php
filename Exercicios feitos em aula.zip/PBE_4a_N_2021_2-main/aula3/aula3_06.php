<?php
<<<<<<< HEAD
$x = null;
echo "x = ".$x."<br>";
var_dump($x);
=======
$_var=true;
echo $_var."<br>";
var_dump($_var);
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>