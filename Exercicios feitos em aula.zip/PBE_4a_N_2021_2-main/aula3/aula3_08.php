<?php
<<<<<<< HEAD
define("PI", 3.14);
define("HOST","localhost");
$valor = 2 * PI;
echo HOST . " - ". $valor;
=======
$nota = 9.5;
$nova_nota = (int)$nota;
var_dump($nota);
echo "<br>";
var_dump($nova_nota);
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>