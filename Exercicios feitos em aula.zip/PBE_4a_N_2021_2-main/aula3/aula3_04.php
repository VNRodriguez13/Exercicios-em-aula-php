<?php
<<<<<<< HEAD
$nome="Claudete";
$sobrenome = 'Maria';
echo $nome ." ".$sobrenome."<br>";
echo "$nome $sobrenome<br>";
//após testar, substitua as aspas acima por simples
=======
$nota = 9.75;
$preco = 100.50;
echo "<br>nota = ".$nota;
echo "<br>preco = ".$preco;
>>>>>>> 27e7bdf33a3db6a6526ea9a3b054faa60f21967b
?>